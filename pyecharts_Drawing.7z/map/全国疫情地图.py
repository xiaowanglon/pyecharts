from pyecharts.charts import Map
from pyecharts.options import *
import json

f = open('E:\RUAN jian project path\Python\pyecharts_Drawing\data\china_data\疫情.txt', 'r', encoding='UTF-8')
data = f.read()
f.close()

data = json.loads(data)

area_data = data['areaTree'][0]['children']
data_list = []
for x in area_data:
    name_data = x['name']    # 省份名称
    confirm_data = x['total']['confirm']   # 确诊人数
    data_list.append((name_data+'省', confirm_data))
china_map = Map()
china_map.add('中国各省确诊情况', data_list, 'china')

china_map.set_global_opts(
    visualmap_opts=VisualMapOpts(
        is_show=True,     # 是否显示
        is_piecewise=True,    # 是否分段
        pieces=[
            {'min': 1, 'max': 99, 'label': '1-99人', 'color': '#CCFFFF'},
            {'min': 100, 'max': 999, 'label': '100-999人', 'color': '#FFFF99'},
            {'min': 1000, 'max': 4999, 'label': '1000-4999人', 'color': '#FF9966'},
            {'min': 5000, 'max': 9999, 'label': '5000-9999人', 'color': '#FF6666'},
            {'min': 10000, 'max': 99999, 'label': '10000-9999人', 'color': '#CC3333'},
            {'min': 100000, 'label': '100000人以上', 'color': '#990033'}
        ]
)
)
china_map.render('我国各省确诊人数.html')