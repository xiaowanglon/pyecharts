from pyecharts.options import *
from pyecharts.charts import Bar, Timeline
from pyecharts.globals import ThemeType

gdp_bar1 = Bar()
gdp_bar1.add_xaxis(['China', 'English', 'America'])
gdp_bar1.add_yaxis('san_GDP', [30, 10, 20], label_opts=LabelOpts(position='right'))
gdp_bar1.reversal_axis()

gdp_bar2 = Bar()
gdp_bar2.add_xaxis(['China', 'English', 'America'])
gdp_bar2.add_yaxis('san_GDP', [40, 20, 30], label_opts=LabelOpts(position='right'))
gdp_bar2.reversal_axis()

gdp_bar3 = Bar()
gdp_bar3.add_xaxis(['China', 'English', 'America'])
gdp_bar3.add_yaxis('san_GDP', [55, 25, 25], label_opts=LabelOpts(position='right'))
gdp_bar3.reversal_axis()

gdp_bar4 = Bar()
gdp_bar4.add_xaxis(['China', 'English', 'America'])
gdp_bar4.add_yaxis('san_GDP', [65, 15, 20], label_opts=LabelOpts(position='right'))
gdp_bar4.reversal_axis()

gdp_bar5 = Bar()
gdp_bar5.add_xaxis(['China', 'English', 'America'])
gdp_bar5.add_yaxis('san_GDP', [70, 20, 25], label_opts=LabelOpts(position='right'))
gdp_bar5.reversal_axis()

gdp_bar6 = Bar()
gdp_bar6.add_xaxis(['China', 'English', 'America'])
gdp_bar6.add_yaxis('san_GDP', [85, 25, 30], label_opts=LabelOpts(position='right'))
gdp_bar6.reversal_axis()

gdp_bar7 = Bar()
gdp_bar7.add_xaxis(['China', 'English', 'America'])
gdp_bar7.add_yaxis('san_GDP', [100, 30, 35], label_opts=LabelOpts(position='right'))
gdp_bar7.reversal_axis()

# 构建时间线对象
timeline_7 = Timeline({'theme': ThemeType.ROMANTIC})

# 在时间线上加点
timeline_7.add(gdp_bar1, "点1")
timeline_7.add(gdp_bar2, "点2")
timeline_7.add(gdp_bar3, "点3")
timeline_7.add(gdp_bar4, "点4")
timeline_7.add(gdp_bar5, "点5")
timeline_7.add(gdp_bar6, "点6")
timeline_7.add(gdp_bar7, "点7")

# 自动播放设置
timeline_7.add_schema(
    play_interval=1000,
    is_timeline_show=True,
    is_auto_play=True,
    is_loop_play=True
)

# 绘图是用时间线对象绘图，而不是bar对象
timeline_7.render('七个时间点时间线柱状图.html')