from pyecharts.options import *
from pyecharts.charts import Bar
gdp_bar = Bar()
gdp_bar.add_xaxis(['China', 'English', 'America'])
gdp_bar.add_yaxis('san_GDP', [30, 10, 20], label_opts=LabelOpts(position='right'))
gdp_bar.reversal_axis()
gdp_bar.render('中英美GDP柱状图.html')