import json
from pyecharts.charts import Line
from pyecharts.options import*
# 处理数据

usf = open("美国.txt", "r", encoding='UTF-8')
us_data_all = usf.read()
usf.close()
rbf = open("日本.txt", "r", encoding='UTF-8')
rb_data_all = rbf.read()
rbf.close()
ydf = open("印度.txt", "r", encoding='UTF-8')
yd_data_all = ydf.read()
ydf.close()

data_us = us_data_all.replace("jsonp_1629344292311_69436(", '')
data_us = data_us[:-2]
data_rb = rb_data_all.replace("jsonp_1629350871167_29498(", '')
data_rb = data_rb[:-2]
data_yd = yd_data_all.replace("jsonp_1629350745930_63180(", '')
data_yd = data_yd[:-2]
# print(data_us)
# print(data_rb)
# print(data_yd)


# JSON数据转换为python字典

u_dict = json.loads(data_us)
r_dict = json.loads(data_rb)
y_dict = json.loads(data_yd)


# 获取x,y轴数据

x_data_day = u_dict['data'][0]['trend']['updateDate'][:314]
y_data_us = u_dict['data'][0]['trend']['list'][0]['data'][:314]
y_data_rb = r_dict['data'][0]['trend']['list'][0]['data'][:314]
y_data_yd = y_dict['data'][0]['trend']['list'][0]['data'][:314]
# print(y_data_yd)
# 开始作图
line = Line() # 构图

# 添加x，y
line.add_xaxis(x_data_day)
line.add_yaxis('美国确诊人数', y_data_us, label_opts=LabelOpts)
line.add_yaxis('日本确诊人数', y_data_rb, label_opts=LabelOpts)
line.add_yaxis('印度确诊人数', y_data_yd, label_opts=LabelOpts)

# 设置全局选项
line.set_global_opts(
    # 标题
    title_opts=TitleOpts(title='2020美日印确诊', pos_right="center", pos_top="95%")

)

# render语法，生成图表
line.render('us_jan_in.html')


